<?php
echo "<div class='topbar'>";
echo "<h1> Rolsa Technologies Surgery</h1>"; #sets a logo up for the top of each page
echo "<br>"; # line break for clarity and easy of reading.
echo "<br>"; # line break for clarity and easy of reading.
echo "</div>";
?>